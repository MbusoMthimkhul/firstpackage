# firstpackege
this library was created to group together recursive and sorting functions.

## building this package locally
`python setup.py sdist`

## installing this package from github
`pip install git+https://github.com/MbusoMthimkhul/firstpackage.git`

## updating this package from github
`pip install --upgrade git+https://github.com/MbusoMthimkhul/firstpackage.git`
